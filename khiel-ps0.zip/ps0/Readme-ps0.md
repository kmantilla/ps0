# PS0: Hello SFML

## Contact
Name: Khiel Mantilla

Section: 202

Time to Complete: an hour


## Description

run a sfml program as i draw a green circle and two sprites. one sprite moves to the right on loop as the second sprite moves on keystroke left or right.

### Features

drawing a green circle

drawing a sprite that moves to the right

drawing a sprite that moves on keystroke left or right

music plays at the start of the program

### Issues

well i have a macbook m1 and so i can't use ubuntu because virtualbox does not support arm and i can't dual boot windows because macos does not support that with m1 and so i just installed SFML with homebrew. the difference with this approach is that i have to use include and library path files such that i can link my g++ compiler to the necessary include and lib folders of SFML.

one can see this so in the makefile and so you probably won't be able to run make at first because i am using brew which is a different approach.

### Extra Credit


## Integrity
Read the University policy Academic Integrity, and answer the following question:

There are six examples of academic misconduct, labeled (a) through (f). Other than (a), "Seeks to claim credit for the work or efforts of another without authorization or citation," which of these do you think would most apply to this class, and why? Write approx. 100-200 words. Note: there is no single correct answer to this. I am looking for your opinion.

i think that (c) forges or falsifies academic documents or records would most apply to class because we are coding in c++ and working to learn more about advanced c++ and so the code files that we have are tangible to how much we learn and appreciate this class for which we can learn c++ and feel a lot more confident as a programmer


## Acknowledgements

https://www.sfml-dev.org/documentation/2.6.0/index.php

https://www.sfml-dev.org/documentation/2.6.0/classsf_1_1Keyboard.php

https://www.sfml-dev.org/tutorials/2.6/graphics-transform.php



### Credits

https://www.deviantart.com/leanboox/art/Anime-Random-Characters-Characters-4-Sprite-805127669

https://www.deviantart.com/leanboox/art/Anime-Random-Characters-Characters-7-Sprite-916980429


