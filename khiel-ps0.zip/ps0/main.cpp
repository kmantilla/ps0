// Copyright 2023 Khiel Mantilla

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

// g++ main.cpp -I/opt/homebrew/Cellar/sfml/2.6.0/include
// -L/opt/homebrew/Cellar/sfml/2.6.0/lib
// -lsfml-graphics -lsfml-window -lsfml-system

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML window");
    // window.setFramerateLimit(80);




    sf::CircleShape shape(100.f);
    shape.setFillColor(sf::Color::Green);

    sf::Texture a_player;
    if (!a_player.loadFromFile("jen.png")) {
        return EXIT_FAILURE;
    }
    sf::Sprite sprite(a_player);

    sf::Texture a_player_2;
    if (!a_player_2.loadFromFile("sprite.png")) {
        return EXIT_FAILURE;
    }
    sf::Sprite sprite2(a_player_2);


    sprite.setPosition(0.0f, 300.0f);
    sprite2.setPosition(300.0f, 0.0f);


    sf::Music music;
    if (!music.openFromFile("song.ogg")) {
        return EXIT_FAILURE;
    }

    music.play();

    while (window.isOpen()) {
        // Process events
        sf::Event event;

        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        window.draw(shape);
        window.draw(sprite);
        window.draw(sprite2);
        window.display();

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
            sprite2.move(sf::Vector2f(0.50f, 0.0));
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
            sprite2.move(sf::Vector2f(-0.50f, 0.0));
        }

        sprite.move(sf::Vector2f(0.10f, 0.0));
    }



    return 0;
}
